import "./App.css";
import axios from "axios";
import FileUpload from "./components/upload";
import { useState, useEffect } from "react";


function App() {
  const [files, setFiles] = useState([]);
  const [newfile, setNewfile] = useState(false);

  useEffect(() => {
    axios.get("http://localhost:5000/getAll").then((response) => {
      setFiles(response.data);
      setNewfile(false);
    });
  }, [newfile]);

  const handleDelete = (id) => {
    axios.delete(`http://localhost:5000/delete/${id}`);
  };

  

  return (
          <>
          <div className="container border ">
            <div className="row">
                
              <div className="card">
                <h5 className="card-header">Drag And Drop Files Here</h5>
                  <div className="card-body">
                    <h5 className="card-title">Drop Here</h5>
                      <div className="App">
                        <FileUpload  setNewfile={setNewfile} />
                      </div>
                  </div>
              </div>
                  
            </div>

              <div className="row">
                <div className="card">
                    <h5 className="card-header">Your Uploaded Files</h5>
                    <div className="card-body">
                    
                    {files?.map((file) => {
                      return (
                        <div>
                          {file.name} --- {file.type} -- {file.size}kb{" "}
                          <button
                            className="btn btn-primary"
                            

                          >
                            Download
                          </button>
                          <button
                          className="btn btn-danger"
                            onClick={() => {
                              handleDelete(file._id);
                              setNewfile(true);
                            }}
                            >
                              delete
                          </button>
                        </div>

                        );
                      })}
                  </div>
                </div>
              </div>

          </div> 
            
    </>
  );
}

              
                
            

            

export default App;
