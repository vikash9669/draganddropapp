import React, { useState } from "react";
import { FileUploader } from "react-drag-drop-files";
import axios from "axios";
const fileTypes = ["JPG", "PNG", "GIF", "mp3", "mp4", "csv", "pdf"];

function DragDrop({ setNewfile }) {
  const [file, setFile] = useState(null);
  const handleChange = async (file) => {
    const form = new FormData();
    form.append("file", file);
    const response = await axios.post("http://localhost:5000/upload", form);
    console.log(response);
    setFile(file);
    setNewfile(true);
  };
  return (
    <>
      <FileUploader handleChange={handleChange} name="file" types={fileTypes} />
      
    </>
  );
}

export default DragDrop;
