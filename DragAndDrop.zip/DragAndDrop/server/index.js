const express = require("express");
const mongoose = require("mongoose");
const app = express();
const cors = require("cors");
const bodyParser = require("body-parser");
const router = require("./routes/routes");

app.use(bodyParser.json());
app.use(cors());
app.use("/", router);

mongoose.connect(
  "mongodb+srv://admin:admin@cluster0.xhxp5ho.mongodb.net/?retryWrites=true&w=majority",
  { useNewUrlParser: true, useUnifiedTopology: true }
);

const port = 5000;
app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
