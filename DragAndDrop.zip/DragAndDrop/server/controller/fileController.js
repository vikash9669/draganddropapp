const UploadFile = require("../models/fileModel");
const fs = require("fs");
const path = require("path");

exports.uploadFile = (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).send("No file uploaded.");
    }
    console.log(req.file);
    const uploadedFile = new UploadFile({
      name: req.file.filename,
      type: req.file.mimetype,
      size: req.file.size,
    });
    uploadedFile.save();
    res.send("File uploaded successfully.");
  } catch (error) {
    console.log(error);
  }
};

exports.getAll = async (req, res) => {
  const data = await UploadFile.find({});
  console.log(data);
  res.json(data);
};

exports.delete = async (req, res) => {
  try {
    const file = await UploadFile.findById(req.params.id);
    const filePath = path.join(__dirname, "../", "uploads", file.name);
    console.log(filePath);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
      await UploadFile.deleteOne({ _id: req.params.id });
      return res.status(200).send("File deleted successfully.");
    }
  } catch (error) {
    console.log(error);
  }
};
