const mongoose = require("mongoose");

const uploadFileSchema = new mongoose.Schema({
  name: String,
  type: String,
  size: String,
});

const UploadFile = mongoose.model("UploadFile", uploadFileSchema);

module.exports = UploadFile;
