const express = require("express");
const fileController = require("../controller/fileController");
const router = express.Router();
const upload = require("../middleware/upload");

router.post("/upload", upload.single("file"), fileController.uploadFile);
router.get("/getAll", fileController.getAll);
router.delete("/delete/:id", fileController.delete);
module.exports = router;
